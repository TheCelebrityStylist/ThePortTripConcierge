/**
 * DayBuilder — "Build my day" on /day/:slug.
 * The traveller says what they love and who is coming; the day is chosen,
 * ordered and timed from the port's checked stops (src/lib/dayStops). They can
 * add, drop, reorder and lengthen stops; every change re-times the day against
 * the checked leave-by table and says plainly what no longer fits.
 */
import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, X, Plus, Minus, CalendarPlus, RotateCcw, AlertTriangle, Share2, Footprints, Bus, Car, Ship, Timer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { fmt, dur } from '@/lib/portDay';
import { INTERESTS, PACES, GROUPS, buildDay, timeDay, lateCuts, extras, toICS } from '@/lib/dayBuilder';

const LOADERS = import.meta.glob('../../lib/dayStops/*.json', { import: 'default' });
export const hasDayStops = (slug) => Boolean(LOADERS[`../../lib/dayStops/${slug}.json`]);

const C = { ink: '#12324A', sea: '#2F7F8F', seaSoft: '#CFE3E3', red: '#C8372D', buoy: '#E8A33D' };
const KIND = { sight: 'Sight', museum: 'Museum', church: 'Church', viewpoint: 'Viewpoint', walk: 'Walk', beach: 'Beach', swim: 'Swim', market: 'Market', food: 'Lunch', snack: 'Snack', activity: 'Activity', daytrip: 'Day trip' };
const MODE_ICON = { walk: Footprints, taxi: Car, ferry: Ship, boat: Ship, tender: Ship };

function track(eventName, properties) {
  try { base44.analytics.track({ eventName, properties }); } catch { /* never blocks */ }
}

function Chip({ on, children, onClick }) {
  return (
    <button type="button" aria-pressed={on} onClick={onClick}
      className={`rounded-full px-3.5 py-2 text-sm font-bold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-[color:var(--pd-sea)] ${on ? 'bg-[color:var(--pd-ink)] text-white' : 'bg-white/80 text-[color:var(--pd-ink)] ring-1 ring-[color:var(--pd-ink)]/15 hover:bg-white'}`}>
      {children}
    </button>
  );
}

function Seg({ label, value, options, onChange }) {
  return (
    <fieldset className="min-w-0">
      <legend className="text-sm text-[color:var(--pd-ink)]/70">{label}</legend>
      <div role="radiogroup" className="mt-1.5 grid auto-cols-fr grid-flow-col gap-1 rounded-xl bg-[color:var(--pd-ink)]/[0.06] p-1">
        {options.map(([v, l]) => (
          <button key={v} type="button" role="radio" aria-checked={value === v} onClick={() => onChange(v)}
            className={`rounded-lg px-2 py-2 text-xs font-bold ${value === v ? 'bg-white shadow-sm' : 'text-[color:var(--pd-ink)]/70 hover:text-[color:var(--pd-ink)]'}`}>{l}</button>
        ))}
      </div>
    </fieldset>
  );
}

const readList = (v) => (v ? v.split('.').filter(Boolean) : []);

export default function DayBuilder({ slug, city, dock, allAboard, isTender, leaveBy, date, wx, params, setParams, tz }) {
  const [data, setData] = useState(null);
  useEffect(() => {
    let off = false;
    const load = LOADERS[`../../lib/dayStops/${slug}.json`];
    if (load) load().then((d) => { if (!off) setData(d); });
    return () => { off = true; };
  }, [slug]);

  // Preferences live in the URL, so a shared link opens the same day.
  const get = (k, d) => params.get(k) ?? d;
  const prefs = useMemo(() => ({
    interests: readList(get('i', '')),
    pace: get('p', 'balanced'),
    group: get('g', 'adults'),
    transport: get('tr', 'public'),
    mobility: get('mob', '') === '1' ? 'limited' : 'any',
    budget: get('bud', '') === '1' ? 'low' : 'any',
  }), [params]); // eslint-disable-line react-hooks/exhaustive-deps
  const setPref = (k, v) => {
    const next = new URLSearchParams(params);
    if (v === '' || v == null) next.delete(k); else next.set(k, v);
    next.delete('o'); next.delete('dx'); // a new brief rebuilds the day
    setParams(next, { replace: true });
    track('day_builder_pref', { slug, key: k });
  };
  const toggleInterest = (t) => {
    const cur = new Set(prefs.interests);
    if (cur.has(t)) cur.delete(t); else cur.add(t);
    setPref('i', [...cur].join('.'));
  };

  const weekday = date ? new Date(`${date}T12:00:00Z`).getUTCDay() : null;
  // Duration changes: "dx=id:+15.id2:-15"
  const dx = useMemo(() => Object.fromEntries(readList(params.get('dx')).map((x) => { const [id, d] = x.split(':'); return [id, Number(d) || 0]; })), [params]);
  const dataX = useMemo(() => data && { ...data, stops: data.stops.map((s) => (dx[s.id] ? { ...s, min: Math.max(15, s.min + dx[s.id]) } : s)) }, [data, dx]);
  const ctx = useMemo(() => ({ dock, allAboard, isTender, leaveBy, prefs, weekday, wx }), [dock, allAboard, isTender, leaveBy, prefs, weekday, wx]);
  const built = useMemo(() => (dataX ? buildDay(dataX, ctx) : null), [dataX, ctx]);
  const custom = readList(params.get('o'));
  const order = custom.length ? custom.filter((id) => dataX?.stops.some((s) => s.id === id)) : (built?.order || []);
  const timed = useMemo(() => (dataX ? timeDay(order, dataX, ctx) : null), [dataX, order, ctx]);
  const late30 = useMemo(() => (dataX && order.length ? lateCuts(order, dataX, ctx, 30) : null), [dataX, order, ctx]);
  const late60 = useMemo(() => (dataX && order.length ? lateCuts(order, dataX, ctx, 60) : null), [dataX, order, ctx]);
  const more = useMemo(() => (dataX ? extras(order, dataX, ctx) : []), [dataX, order, ctx]);
  const [showMore, setShowMore] = useState(false);
  const [copied, setCopied] = useState(false);

  if (!data) return <p className="rounded-2xl bg-white/70 p-4 text-sm">Loading the {city} stops…</p>;

  const setOrder = (o, what) => {
    const next = new URLSearchParams(params);
    next.set('o', o.join('.'));
    setParams(next, { replace: true });
    track('day_builder_edit', { slug, what });
  };
  const move = (id, d) => { const o = [...order]; const i = o.indexOf(id); const j = i + d; if (j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; setOrder(o, 'move'); };
  const drop = (id) => setOrder(order.filter((x) => x !== id), 'remove');
  const add = (id) => {
    // Put it in its own area, before the last stop there, or at the end.
    const s = data.stops.find((x) => x.id === id);
    const o = [...order];
    const lastSame = o.map((x) => data.stops.find((y) => y.id === x)?.area).lastIndexOf(s.area);
    o.splice(lastSame >= 0 ? lastSame + 1 : o.length, 0, id);
    setOrder(o, 'add');
  };
  const stretch = (id, d) => {
    const next = new URLSearchParams(params);
    const cur = { ...dx, [id]: (dx[id] || 0) + d };
    const v = Object.entries(cur).filter(([, m]) => m).map(([k, m]) => `${k}:${m}`).join('.');
    if (v) next.set('dx', v); else next.delete('dx');
    if (!custom.length) next.set('o', order.join('.'));
    setParams(next, { replace: true });
  };
  const reset = () => { const next = new URLSearchParams(params); next.delete('o'); next.delete('dx'); setParams(next, { replace: true }); track('day_builder_reset', { slug }); };

  const ics = () => {
    const text = toICS({ city, date, timed, tz });
    if (!text) return;
    const url = URL.createObjectURL(new Blob([text], { type: 'text/calendar' }));
    const a = document.createElement('a'); a.href = url; a.download = `porttrip-${slug}-${date}.ics`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    track('day_builder_calendar', { slug });
  };
  const share = async () => {
    const url = window.location.href;
    const text = `My ${city} day: ${timed.items.filter((i) => i.type === 'stop').map((i) => i.stop.name.split(/[,(]/)[0]).join(', ')}. Leave ${timed.leave.from} by ${fmt(timed.leave.at)}.`;
    track('day_builder_share', { slug });
    try {
      if (navigator.share) await navigator.share({ title: `${city} port day`, text, url });
      else { await navigator.clipboard.writeText(`${text} ${url}`); setCopied(true); setTimeout(() => setCopied(false), 2500); }
    } catch { /* cancelled */ }
  };

  const hasTaxi = data.areas.some((a) => a.id !== 'centre' && a.modes.some((m) => m.mode === 'taxi') && a.modes.some((m) => m.mode !== 'taxi'));
  const stops = timed.items.filter((i) => i.type === 'stop');
  const reds = stops.filter((i) => i.warnings.some((w) => w.level === 'red'));
  const nameOf = (id) => data.stops.find((s) => s.id === id)?.name;

  return (
    <section aria-label="Build my day" className="space-y-5">
      {/* The brief */}
      <div className="space-y-4 rounded-3xl bg-white/70 p-4 sm:p-5">
        <div>
          <p className="text-sm text-[color:var(--pd-ink)]/70">What do you love?</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {INTERESTS.map(([k, l]) => <Chip key={k} on={prefs.interests.includes(k)} onClick={() => toggleInterest(k)}>{l}</Chip>)}
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Seg label="Pace" value={prefs.pace} options={PACES} onChange={(v) => setPref('p', v === 'balanced' ? '' : v)} />
          <Seg label="Who's going" value={prefs.group} options={GROUPS} onChange={(v) => setPref('g', v === 'adults' ? '' : v)} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Chip on={prefs.mobility === 'limited'} onClick={() => setPref('mob', prefs.mobility === 'limited' ? '' : '1')}>Avoid steps and climbs</Chip>
          <Chip on={prefs.budget === 'low'} onClick={() => setPref('bud', prefs.budget === 'low' ? '' : '1')}>Keep it cheap</Chip>
          {hasTaxi && <Chip on={prefs.transport === 'taxi'} onClick={() => setPref('tr', prefs.transport === 'taxi' ? '' : 'taxi')}>Taxis, not buses</Chip>}
        </div>
      </div>

      {/* The verdict */}
      <div className="rounded-3xl p-4 text-white sm:p-5" style={{ background: C.ink }}>
        <p className="font-display text-2xl font-black leading-tight">
          Leave {timed.leave.from} by <span className="tabular-nums" style={{ color: '#FFB4AC' }}>{fmt(timed.leave.at)}</span>
        </p>
        <p className="mt-1 text-sm text-white/80">
          {stops.length} {stops.length === 1 ? 'stop' : 'stops'}
          {timed.spare >= 0 ? ` · ${dur(timed.spare)} to spare` : ` · ${dur(-timed.spare)} too long`}
          {' · '}{timed.cost.eur ? `about €${Math.round(timed.cost.eur)} a person in entry fees` : 'no entry fees we know of'}
          {timed.cost.unknown ? ` (+${timed.cost.unknown} priced on the day)` : ''}
        </p>
        <p className="mt-1 text-xs text-white/60">{timed.leave.how}{custom.length ? ' · Your edits' : ' · Built for your choices'}</p>
      </div>

      {stops.length === 0 && (
        <p className="rounded-2xl px-4 py-3 text-sm" style={{ background: '#FBEBD0' }}>
          None of the {city} stops fits between {fmt(timed.ashore)} and {fmt(timed.leave.at)}. Stay close to the pier, or add a short stop below and watch the times.
        </p>
      )}
      {stops.length > 0 && timed.spare >= 90 && (
        <p className="rounded-2xl bg-white/70 px-4 py-3 text-sm">
          You have {dur(timed.spare)} spare. Add a stop below, or keep it for a slow lunch and an easy walk back.
        </p>
      )}
      {reds.length > 0 && (
        <p className="flex items-start gap-2 rounded-2xl px-4 py-3 text-sm font-bold" style={{ background: '#F7D9D6' }}>
          <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0" style={{ color: C.red }} />
          {reds.length === 1 ? `${reds[0].stop.name} does not fit.` : `${reds.length} stops do not fit.`} Drop or shorten something, or move it earlier.
        </p>
      )}

      {/* The day */}
      <ol className="space-y-2">
        <li className="flex items-center gap-3 px-1 text-sm text-[color:var(--pd-ink)]/75"><Ship className="h-4 w-4" /> Ashore from <b className="tabular-nums">{fmt(timed.ashore)}</b>{isTender ? ' (first tenders)' : ''}</li>
        {timed.items.map((it, idx) => {
          if (it.type === 'travel') {
            const Icon = MODE_ICON[it.mode] || Bus;
            return (
              <li key={`t${idx}`} className="flex items-start gap-3 px-1 text-sm text-[color:var(--pd-ink)]/75">
                <Icon className="mt-0.5 h-4 w-4 flex-shrink-0" />
                <span><b className="tabular-nums">{fmt(it.start)}</b> to {it.toName}: {it.how}{it.est ? ' (estimated via the port side)' : ''}</span>
              </li>
            );
          }
          if (it.type === 'wait') return <li key={`w${idx}`} className="px-1 text-sm text-[color:var(--pd-ink)]/65"><Timer className="mr-2 inline h-4 w-4" />Opens at {fmt(it.end)}</li>;
          const s = it.stop;
          const red = it.warnings.some((w) => w.level === 'red');
          const i = order.indexOf(it.id);
          return (
            <li key={it.id} className={`rounded-2xl bg-white/85 p-4 ring-1 ${red ? 'ring-[color:var(--pd-red)]/60' : 'ring-[color:var(--pd-ink)]/[0.06]'}`}>
              <div className="flex items-start gap-3">
                <p className="w-[4.5rem] flex-shrink-0 font-display text-xl font-black tabular-nums leading-tight">{fmt(it.start)}<span className="block text-xs font-bold text-[color:var(--pd-ink)]/55">to {fmt(it.end)}</span></p>
                <div className="min-w-0 flex-1">
                  <p className="font-bold leading-snug">{s.name}</p>
                  <p className="mt-0.5 text-xs text-[color:var(--pd-ink)]/65">{KIND[s.kind] || 'Stop'} · {dur(s.min)}{s.est ? ' (our estimate)' : ''}{s.cost ? ` · ${s.cost}` : ''}</p>
                  {s.note && <p className="mt-1.5 text-sm leading-relaxed text-[color:var(--pd-ink)]/85">{s.note}</p>}
                  {s.hours && <p className="mt-1 text-xs text-[color:var(--pd-ink)]/60">Hours: {s.hours}</p>}
                  {it.warnings.map((w) => (
                    <p key={w.text} className="mt-1.5 text-xs font-bold" style={{ color: w.level === 'red' ? C.red : w.level === 'amber' ? '#9A6214' : C.sea }}>{w.text}</p>
                  ))}
                  <div className="mt-2 flex flex-wrap items-center gap-1">
                    <button type="button" aria-label="Move earlier" disabled={i <= 0} onClick={() => move(it.id, -1)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-[color:var(--pd-ink)]/[0.06] disabled:opacity-30"><ArrowUp className="h-4 w-4" /></button>
                    <button type="button" aria-label="Move later" disabled={i >= order.length - 1} onClick={() => move(it.id, 1)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-[color:var(--pd-ink)]/[0.06] disabled:opacity-30"><ArrowDown className="h-4 w-4" /></button>
                    <button type="button" aria-label="15 minutes shorter" onClick={() => stretch(it.id, -15)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-[color:var(--pd-ink)]/[0.06]"><Minus className="h-4 w-4" /></button>
                    <button type="button" aria-label="15 minutes longer" onClick={() => stretch(it.id, 15)} className="grid h-8 w-8 place-items-center rounded-full hover:bg-[color:var(--pd-ink)]/[0.06]"><Plus className="h-4 w-4" /></button>
                    <button type="button" onClick={() => drop(it.id)} className="ml-auto flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-bold hover:bg-[color:var(--pd-ink)]/[0.06]"><X className="h-3.5 w-3.5" /> Remove</button>
                  </div>
                </div>
              </div>
            </li>
          );
        })}
        <li className="flex items-start gap-3 rounded-2xl px-4 py-3" style={{ background: '#F7D9D6' }}>
          <span className="font-display text-xl font-black tabular-nums" style={{ color: C.red }}>{fmt(timed.leave.at)}</span>
          <span className="text-sm"><b>Leave {timed.leave.from}.</b> {timed.leave.how}. This is the latest time from the checked guide; it already counts the way back{isTender ? ' and the tender queue' : ''}.</span>
        </li>
      </ol>

      {/* Plan B */}
      {(late30?.cut.length > 0 || late60?.cut.length > 0) && (
        <div className="rounded-3xl bg-white/70 p-4 sm:p-5">
          <p className="font-display text-lg font-black">Running late?</p>
          <ul className="mt-2 space-y-1.5 text-sm">
            {late30?.cut.length > 0 && <li><b>30 minutes behind:</b> skip {late30.cut.map(nameOf).join(', then ')}.</li>}
            {late60?.cut.length > 0 && <li><b>An hour behind:</b> skip {late60.cut.map(nameOf).join(', then ')}.</li>}
          </ul>
          <p className="mt-2 text-xs text-[color:var(--pd-ink)]/60">The leave-by time never moves. What goes first is the stop that matters least to you.</p>
        </div>
      )}

      {/* Add more */}
      <div className="rounded-3xl bg-white/70 p-4 sm:p-5">
        <button type="button" onClick={() => setShowMore((v) => !v)} aria-expanded={showMore} className="flex w-full items-center justify-between font-display text-lg font-black">
          Add to your day <span className="text-sm font-bold text-[color:var(--pd-ink)]/60">{more.length} more in {city}</span>
        </button>
        {showMore && (
          <ul className="mt-3 divide-y divide-[color:var(--pd-ink)]/10">
            {more.map(({ stop: s, e }) => (
              <li key={s.id} className="flex items-start justify-between gap-3 py-3">
                <span className="min-w-0">
                  <span className="block font-bold leading-snug">{s.name}</span>
                  <span className="block text-xs text-[color:var(--pd-ink)]/65">
                    {KIND[s.kind] || 'Stop'} · {dur(s.min)}{s.area !== 'centre' ? ` · ${data.areas.find((a) => a.id === s.area)?.name}` : ''}{s.cost ? ` · ${s.cost}` : ''}
                  </span>
                  {!e.ok && <span className="block text-xs font-bold" style={{ color: '#9A6214' }}>{e.why}</span>}
                </span>
                <button type="button" onClick={() => add(s.id)} className="flex flex-shrink-0 items-center gap-1 rounded-full bg-[color:var(--pd-ink)] px-3 py-1.5 text-xs font-bold text-white"><Plus className="h-3.5 w-3.5" /> Add</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={ics} disabled={!date} title={date ? '' : 'Set your port date first'}
          className="flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold text-white disabled:opacity-50" style={{ background: C.sea }}>
          <CalendarPlus className="h-4 w-4" /> {date ? 'Add to calendar, with alarms' : 'Set your port date to add it to your calendar'}
        </button>
        <button type="button" onClick={share} className="flex items-center gap-1.5 rounded-full border border-[color:var(--pd-ink)]/25 px-4 py-2 text-sm font-bold hover:bg-white">
          <Share2 className="h-4 w-4" /> {copied ? 'Link copied' : 'Share this day'}
        </button>
        {custom.length > 0 && (
          <button type="button" onClick={reset} className="flex items-center gap-1.5 rounded-full px-4 py-2 text-sm font-bold hover:bg-white">
            <RotateCcw className="h-4 w-4" /> Rebuild from my choices
          </button>
        )}
      </div>
      <p className="text-xs text-[color:var(--pd-ink)]/60">
        Every stop, price and opening time comes from the checked {city} guide. Times between places are the guide's own; inside town we allow 10 minutes' walk between stops.{built?.alternatives?.length ? '' : ''}
      </p>
    </section>
  );
}
