/**
 * DayRouteMap — the traveller's own day on a map: the ship, each stop numbered
 * with its time, Google Maps walking lines between them, and the red leave-by pin.
 */
import { useEffect, useRef, useState } from 'react';
import { fmt } from '@/lib/portDay';

const INK = '#12324A', SEA = '#2F7F8F', RED = '#C8372D';
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function decode(str) {
  const pts = []; let i = 0, lat = 0, lng = 0;
  while (i < str.length) {
    let b, shift = 0, res = 0;
    do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lat += (res & 1) ? ~(res >> 1) : res >> 1;
    shift = 0; res = 0;
    do { b = str.charCodeAt(i++) - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lng += (res & 1) ? ~(res >> 1) : res >> 1;
    pts.push([lat / 1e5, lng / 1e5]);
  }
  return pts;
}
function ensureCss() {
  if (document.getElementById('leaflet-css')) return;
  const link = document.createElement('link');
  link.id = 'leaflet-css'; link.rel = 'stylesheet';
  link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  document.head.appendChild(link);
}
const num = (n, t, warn) => `<div style="transform:translate(-50%,-50%);display:flex;align-items:center;gap:4px;white-space:nowrap">
  <span style="display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:${warn ? RED : INK};color:#fff;font:900 13px/1 system-ui,sans-serif;box-shadow:0 0 0 3px #fff">${n}</span>
  <span style="font:800 12px/1 system-ui,sans-serif;font-variant-numeric:tabular-nums;background:#fff;color:${INK};padding:3px 6px;border-radius:999px;box-shadow:0 1px 3px rgba(0,0,0,.25)">${esc(t)}</span></div>`;
const SHIP = `<div style="transform:translate(-50%,-50%);width:30px;height:30px;border-radius:50%;background:${INK};display:grid;place-items:center;box-shadow:0 0 0 4px rgba(255,255,255,.9)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="5" r="2.5"/><path d="M12 7.5V21M5 12H2a10 10 0 0 0 20 0h-3"/></svg></div>`;
const LEAVE = (t) => `<div style="transform:translate(-50%,-100%);display:flex;flex-direction:column;align-items:center"><span style="font:900 13px/1 system-ui,sans-serif;font-variant-numeric:tabular-nums;padding:5px 8px;border-radius:999px;background:${RED};color:#fff;white-space:nowrap">Leave ${esc(t)}</span><span style="width:2px;height:8px;background:${RED}"></span></div>`;

export default function DayRouteMap({ slug, timed, polys = [], areaLines = [] }) {
  const box = useRef(null);
  const ref = useRef(null);
  const layer = useRef(null);
  const [pier, setPier] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let off = false;
    fetch(`/data/routes/${slug}.json`).then((r) => (r.ok ? r.json() : null)).then((j) => { if (!off && j) setPier(j); }).catch(() => {});
    return () => { off = true; };
  }, [slug]);

  useEffect(() => {
    if (!box.current || ref.current) return undefined;
    let cancelled = false;
    (async () => {
      ensureCss();
      const L = (await import('leaflet')).default;
      if (cancelled || !box.current) return;
      const map = L.map(box.current, { scrollWheelZoom: false, tap: true });
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> · Places and walking routes: Google Maps', maxZoom: 19 }).addTo(map);
      ref.current = { map, L };
      setTimeout(() => map.invalidateSize(), 60);
      setReady(true);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const m = ref.current;
    if (!m || !ready || !timed) return;
    layer.current?.remove();
    const g = m.L.layerGroup().addTo(m.map);
    layer.current = g;
    const pts = [];
    if (pier?.pier) { const p = [pier.pier.lat, pier.pier.lng]; pts.push(p); m.L.marker(p, { icon: m.L.divIcon({ html: SHIP, className: '', iconSize: [0, 0] }), title: 'Your ship' }).addTo(g).bindPopup(`<b>Your ship</b><br>${esc(pier.pier.name)}`); }
    // Travel between areas: the checked route lines from the guide data, where we have them.
    for (const poly of areaLines) if (poly) m.L.polyline(decode(poly), { color: INK, weight: 3, opacity: 0.35 }).addTo(g);
    // Walking lines from Google Maps; straight dashes until they arrive.
    if (polys.some(Boolean)) {
      for (const poly of polys) if (poly) m.L.polyline(decode(poly), { color: SEA, weight: 5, opacity: 0.85, lineCap: 'round' }).addTo(g);
    }
    let n = 0, prev = null;
    for (const it of timed.items) {
      if (it.type !== 'stop') continue;
      n += 1;
      const s = it.stop;
      if (typeof s.lat !== 'number') continue;
      const p = [s.lat, s.lng];
      pts.push(p);
      if (!polys.some(Boolean) && prev) m.L.polyline([prev, p], { color: SEA, weight: 3, opacity: 0.7, dashArray: '4 8' }).addTo(g);
      prev = p;
      const warn = it.warnings.some((w) => w.level === 'red');
      const link = s.uri ? `<br><a href="${esc(s.uri)}" target="_blank" rel="noopener">Open in Google Maps</a>` : '';
      m.L.marker(p, { icon: m.L.divIcon({ html: num(n, fmt(it.start), warn), className: '', iconSize: [0, 0] }), title: s.name, zIndexOffset: 500 })
        .addTo(g).bindPopup(`<b>${n}. ${esc(s.name)}</b><br>${fmt(it.start)}–${fmt(it.end)}${link}`);
    }
    const L0 = timed.leave;
    if (typeof L0.lat === 'number') {
      const p = [L0.lat, L0.lng]; pts.push(p);
      m.L.marker(p, { icon: m.L.divIcon({ html: LEAVE(fmt(L0.at)), className: '', iconSize: [0, 0] }), zIndexOffset: 1000, title: `Leave ${L0.from} by ${fmt(L0.at)}` })
        .addTo(g).bindPopup(`<b>Leave ${esc(L0.from)} by ${fmt(L0.at)}</b><br>${esc(L0.how)}`);
    }
    if (pts.length) m.map.fitBounds(m.L.latLngBounds(pts), { padding: [32, 32], maxZoom: 16 });
  }, [timed, polys, areaLines, pier, ready]);

  useEffect(() => () => { ref.current?.map.remove(); ref.current = null; }, []);

  return <div ref={box} className="h-[320px] w-full overflow-hidden rounded-3xl bg-[#dfe8e6] sm:h-[400px]" style={{ zIndex: 0 }} aria-label="Map of your day" />;
}
