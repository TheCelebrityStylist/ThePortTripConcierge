import fs from 'fs';
import { buildDay, timeDay, lateCuts, toICS } from '/app/src/lib/dayBuilder.js';
const SD = JSON.parse(fs.readFileSync('/app/src/lib/seo/shipDayData.json'));
const G = (s) => JSON.parse(fs.readFileSync(`/app/src/lib/seo/verifiedGuides/${s}.json`));
const toMin = (t) => { const m = /^(\d{1,2}):(\d{2})/.exec(String(t || '')); return m ? +m[1] * 60 + +m[2] : null; };
const fmt = (x) => `${String(Math.floor(x / 60)).padStart(2, '0')}:${String(x % 60).padStart(2, '0')}`;
const slugs = process.argv.slice(2).length ? process.argv.slice(2) : fs.readdirSync('/app/src/lib/dayStops').filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5));
const PREFS = [
  {}, { interests: ['history'] }, { interests: ['beach'], group: 'family' }, { interests: ['views', 'active'], pace: 'full' },
  { group: 'older', mobility: 'limited', pace: 'easy' }, { interests: ['food'], budget: 'low' }, { transport: 'taxi', interests: ['views'] },
];
let fails = 0;
const verbose = process.argv.length === 3;
for (const slug of slugs) {
  const data = JSON.parse(fs.readFileSync(`/app/src/lib/dayStops/${slug}.json`)); const g = G(slug);
  const dock = toMin((/(\d{1,2}:\d{2})/.exec(g.dayPlan?.intro || '') || [])[1]) ?? 480;
  const aa = toMin(g.dayPlan?.allAboard) ?? 1050;
  for (const [ai, AA] of [[0, aa], [1, aa - 180]]) for (const prefs of PREFS) for (const wx of [{}, { rain: true }, { hot: true }]) {
    const ctx = { dock, allAboard: AA, isTender: !!g.isTender, leaveBy: SD[slug].leaveBy, prefs, weekday: 1, wx };
    const b = buildDay(data, ctx); const t = timeDay(b.order, data, ctx);
    const bad = !t.fits;
    if (bad || !b.order.length) { fails++; if (fails < 15) console.log('FAIL', slug, fmt(AA), JSON.stringify(prefs), JSON.stringify(wx), b.order.length, 'spare', t.spare); }
    if (verbose && ai === 0 && !wx.rain && !wx.hot) {
      console.log(`\n${slug} AA ${fmt(AA)} ${JSON.stringify(prefs)} areas=${b.areas}`);
      for (const i of t.items) console.log(' ', fmt(i.start), i.type === 'stop' ? `${i.stop.name} (${i.stop.min}m)${i.warnings.map((w) => ' !' + w.text).join('')}` : i.type === 'travel' ? `→ ${i.toName} [${i.how}]` : i.type);
      console.log('  LEAVE', t.leave.from, fmt(t.leave.at), 'spare', t.spare, 'cost', JSON.stringify(t.cost));
      const l = lateCuts(b.order, data, ctx, 60); console.log('  late60 cut', l.cut.join(','));
    }
  }
}
console.log('slugs', slugs.length, 'fails', fails);
